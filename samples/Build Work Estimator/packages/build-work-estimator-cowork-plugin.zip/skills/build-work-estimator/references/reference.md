# Methodology

**Author:** Dewain Robinson

How this estimator arrives at a number, and why it is built the way it is.

---

## The premise: measure, don't assume

The obvious way to estimate an agentic build is to reason about it — how big is
the feature, how many files, how hard does it feel — and produce a figure. That
approach fails badly, and it fails in a specific, repeatable direction.

It fails because the intuitive cost drivers are the wrong ones. People reason
about **lines of code** and **feature complexity**. The actual drivers are
**how many turns the agent takes** and **how large the context is on each
turn**. Those correlate only loosely with how big the feature looks.

So the estimator does not reason about the work. It **measures what similar work
actually cost on this machine**, then scales.

## Where the money goes

Agentic coding is input-dominated. Every turn resends the whole conversation, so
the same tokens are re-read on every request. A representative cost breakdown
looks like this:

| Component | Share of spend | Share of tokens |
| --- | ---: | ---: |
| Cache read | ~68% | ~98% |
| Cache write | ~24% | ~2% |
| Output | ~8% | ~0.2% |
| Fresh input | ~0% | ~0% |

**Cost is context re-reading.** Output is a rounding error. That single fact
determines the model: don't carefully account for output tokens, account for
turns and context size.

The workable approximation is:

```
cost_per_turn ≈ context_size_in_thousands × (input_rate × cache_read_multiplier / 1000)
```

which for an Opus-tier model at 0.1× cache read comes out near
`context_k × $0.0005`, plus a smaller output term. In practice the estimator
does not use this formula at all — it uses the **measured** `cost_per_turn` from
real history, which absorbs the model mix, cache behaviour, and subagent
overhead automatically.

## The model

```
turns_i     = bucket_median_turns(size_i) × brownfield_factor × correction_factor
cost_i      = turns_i × cost_per_main_turn × subagent_multiplier
base        = Σ cost_i

low         = Σ ( cost_i × bucket_min_i / bucket_median_i )
high        = Σ ( cost_i × bucket_max_i / bucket_median_i × (1 + 0.25 × unknowns_i) )

reserve     = base × reserve_percent / 100
budget_ask  = base + reserve
```

Ranges are summed per item, not multiplied as ratios against the total — a
common mistake that makes multi-item estimates wrong in a way that is hard to
see.

## Buckets

Work is classified by **distinct files touched**, because that is something both
the estimator and the historical record can count consistently:

| Bucket | Files touched |
| --- | --- |
| `exploration` | 0 — research, reading, no edits |
| `trivial` | 1 |
| `small` | 2–5 |
| `medium` | 6–15 |
| `large` | 16–50 |
| `subsystem` | 51+ |

Calibration derives a median turn count and a cost range for each bucket from
real sessions. The number of sessions behind each bucket (`n`) travels with the
figure everywhere it is shown, because a median over three sessions and a median
over thirty are not the same kind of claim.

## Why the range matters more than the point

Within a single bucket, observed cost routinely spans **more than 100×**. A
medium-sized change can come in at a few dollars or several hundred, depending
on how many debug loops it needs, how much context accumulates, and whether the
session stays warm.

This has a direct consequence: **the point estimate is nearly meaningless on its
own.** The estimator always reports a range, and treats the point figure as the
midpoint of a guess rather than a prediction.

It also means the **contingency reserve is the important number**, which is why
it is a required input rather than an optional one.

## Reserve adequacy

Most estimating tools take a contingency percentage and add it. This one adds
it *and then checks whether it was enough*:

```
if budget_ask < high:
    required_pct = (high - base) / base × 100
```

If a 25% reserve covers to $636 while comparable work has reached $2,989, the
report says so and states that 488% would be required for full coverage.

That is usually the most useful line in the report. The common failure is not a
wrong point estimate — it is a reserve too thin for how wide the real spread is,
carried into a budget conversation without anyone noticing.

## Corrections from actuals

Recording what a build actually cost produces a per-bucket ratio of actual to
estimated turns. Applying that ratio raw would be a mistake: with one recorded
actual, it is a sample of size one.

So observed ratios are **shrunk toward 1.0** in proportion to sample size:

```
shrunk_ratio = 1 + (median_ratio − 1) × n / (n + 3)
applied      = n ≥ 2
```

One actual moves a future estimate 25% of the way toward the observed ratio.
Five move it 63%. Twenty move it 87%. A single surprising build cannot swing
everything that follows, which is the same over-confidence this estimator exists
to prevent.

## What is deliberately not modelled

- **Runtime cost of what gets built.** Different drivers entirely.
- **Human labour, licences, infrastructure.** Not agent inference.
- **Wall-clock time.** Turns are not minutes; a long session and a fast one can
  cost the same.
- **Quality.** A cheaper build is not a better one, and this says nothing about
  whether the output is any good.

## The honest limits

1. **Turn counts per bucket are the weakest input.** Everything else is
   arithmetic on measured values; the turn medians carry the uncertainty.
2. **List pricing.** Contracted rates change the answer materially.
3. **One machine.** Other devices and claude.ai sessions are invisible.
4. **Self-selection in the community baseline.** It reflects who contributed,
   not a representative population.
5. **It is a sample.** The point is the method, not the constants.

---

# Platforms and licensing

**Author:** Dewain Robinson

Two questions decide what a build estimate says. Getting either wrong produces
a number that looks reasonable and is wrong.

1. **What are you building WITH?** — the build platform, decides the build-side meter.
2. **What are you building ON?** — the target platform, decides the target-side meter.
3. **How is that licensed?** — decides what the numbers *mean*.

They are additive, not alternatives: the same project spends on both meters at
the same time.

---

## 1. Two platforms, two meters

**Copilot Studio is not a build platform.** An AI-assisted build happens in a
coding agent — Claude Code or GitHub Copilot — authoring the agent definition.
Copilot Studio is where the result is deployed, previewed, evaluated, and
validated by a human. Microsoft's own VS Code extension documentation says so
directly, naming *"GitHub Copilot, Claude Code, or your favorite agent"* as the
harnesses used to create and update Copilot Studio agent components, under a
heading titled **Agent-driven development**.

| | Values | Meter |
| --- | --- | --- |
| `build_platform` | `claude-code` · `github-copilot` | Tokens → USD, or GitHub AI Credits |
| `target_platform` | `copilot-studio` · `azure` · `both` · `ai-recommend` | Copilot Credits, or Azure consumption |

Two earlier versions of this estimator got this wrong. The first keyed off
`microsoft: true` — meaning *the target is Microsoft* — and priced those builds
in Copilot Credits. The second treated `copilot-studio` as a build stack, which
models a workflow nobody performs. Both keys were removed rather than kept
working, and both are rejected with guidance.

### The target harness decides whether any of it bills

Required whenever the target is Copilot Studio:

| Harness | Build, preview, test, evaluate |
| --- | --- |
| `standard` | **Not billed.** Billing starts after publish; embedded test chat does not count |
| `github-copilot` | **Billed from the moment building starts** |

A standard-harness target legitimately returns near-zero target-side cost. The
report says so plainly and shows what the same work would have cost on the other
harness, so the difference is visible rather than hidden. Billable side-effects
— agent flow runs, content processing — still bill on either harness.

### The evaluation loop is the cost driver

```
  build platform            target platform
  ---------------           ----------------
  author definition   -->   deploy
                            preview / interactive test   <- human, in the UI
                            run evaluations
  remediate           <--   evaluations fail
  (repeat)
```

Microsoft's guidance is explicit that evaluation is a continuous cycle, targeting
an 80–90% pass rate with near 100% on core tests, and that a test set should be
run multiple times for response variability. So an estimate must plan for
cycles, not a single pass: each cycle after the first adds remediation back onto
the build platform, and re-runs the evaluations on the target.

**Evaluations are capped at 20 per agent node per day.** A large test set
therefore sets a minimum elapsed time no amount of budget shortens — the report
states that separately from cost.

**Human validation is a dependency, not a cost line.** Someone must work in the
Copilot Studio interface between cycles to confirm behaviour and adjust
configuration. Planned hours are collected to size the interactive test volume;
they are never priced as labour, consistent with this tool metering agent
consumption rather than people.

### Microsoft products do not bill in tokens

A Copilot Studio report is denominated in **Copilot Credits** throughout — every
heading, total, unit, and row label. Tokens appear only in the *Basis* column,
because Microsoft's own published rate is literally "10 Copilot Credits per 1K
tokens" and removing that would make the credit figure unverifiable. A test
enforces this: no heading and no row label may be denominated in tokens.

### GitHub AI Credits are not Copilot Credits

This one is a trap. **Both are $0.01 per credit.** They are different meters, on
different products, with separate allowances:

| | Copilot Studio | GitHub Copilot |
| --- | --- | --- |
| Unit | Copilot Credit | GitHub AI Credit |
| Rate | $0.01 | $0.01 |
| Allowance | Capacity packs, 25,000/month | Pooled at billing-entity level |
| Meter | Power Platform / M365 | GitHub billing |

Reporting one as the other would produce a plausible number drawn against the
wrong budget. They never share a code path here.

GitHub also runs **two billing models in parallel**:

- **AI Credits** (usage-based) — interactions consume input, output, and cached
  tokens; GitHub prices those at the model's published rates and converts to
  credits. Business and Enterprise pool credits at the billing-entity level.
- **Legacy premium requests** — one request per interaction times a model
  multiplier, drawn from a monthly plan allowance. Eligible Pro and Pro+
  subscribers on existing annual plans stay on this until their plan expires.

**Code completions and next edit suggestions consume no credits** and are
unlimited on paid plans, so however heavily they are used they contribute
nothing to a build estimate.

Per-model rates and multipliers are **not hardcoded**. GitHub publishes and
changes them; a stale table here would misprice every estimate. The user
supplies the rate for the model they actually use.

---

## 2. Licensing decides what the number means

| Licensing | The real question |
| --- | --- |
| **Consumption** — Claude API/Console, Bedrock, Vertex, Foundry, Copilot Studio pay-as-you-go, GitHub usage-based | **What will this cost?** |
| **Seat / allowance** — Claude Pro, Max, Team, Enterprise; GitHub Business/Enterprise; prepaid capacity packs | **Will this fit, and what share of the seat does it burn?** |

### A seat is not free

From the Claude Code documentation: *"Usage inside the seat allowance isn't
metered in dollars."* Marginal spend inside an allowance is zero.

Reporting `$0` for a seat-based build would be the same class of error this tool
exists to prevent. The seat was bought with real money. A build consuming 40% of
a month's allowance carries 40% of that month's seat cost:

```
allowance_share    = build_notional_cost / typical_monthly_cost
attributable_cost  = seat_monthly_cost × seats × allowance_share
```

`typical_monthly_cost` comes from measured history — the calibration profile's
total spend over its date range, extrapolated to 30 days. With fewer than 14
days of history the denominator would be guesswork, so the tool **declines to
compute a share** rather than inventing one.

Seat prices are **not hardcoded**. They change, they vary by contract and
region, and a stale table would silently misattribute every estimate. The user
supplies their actual seat cost; `seat_monthly_cost` is required for seat
licensing and there is no default.

### Overrun is the failure that actually stops work

A build fitting inside an allowance in isolation can still overrun once other
work is counted. `other_workload_share` is required for seat licensing — it is
the fraction of the allowance period already committed elsewhere:

```
total_committed = allowance_share + other_workload_share
overruns        = total_committed > 1.0
```

When it overruns, the report states by how much and what the overage would cost
at the same rate, then lists the options: spread the build across periods, move
part of it to consumption billing, add seats, or reduce the other work.

### Short windows stall before monthly totals do

Claude seat allowances refill on **5-hour rolling** and **weekly** windows, not
only monthly. A build comfortably inside a month can still exhaust a short
window and stall repeatedly.

Set `concentrated: true` when the build is compressed into a short delivery
window; the report then warns that monthly headroom will not protect it.

There is a second, subtler effect: **cache lifetime is one hour on a
subscription and five minutes on an API key.** Cache misses reprocess the full
context, and cache writes were roughly a quarter of measured spend — so the same
build can cost materially more on consumption billing purely from cache
behaviour.

---

## What this is not

**This is not a stack comparison tool.** It reports one stack, in that stack's
own currency, and every report says so.

Technology stack decisions are not made on cost alone. Capability, existing
team skills, governance, integration surface, and support all weigh more than a
build-time figure. A tool that made stack choice look like an arithmetic
comparison would be encouraging a bad decision process — so the shipped examples
each show a single stack, and there is no side-by-side mode in them.

---

# Anthropic rates

**Author:** Dewain Robinson
**Verified:** 2026-09-03
**Source:** https://docs.claude.com/en/docs/about-claude/pricing

List price, USD per 1M tokens.

| Model | Input | Output |
| --- | ---: | ---: |
| `claude-opus-4` | $15.00 | $75.00 |
| `claude-opus-4-1` | $15.00 | $75.00 |
| `claude-fable-5` | $10.00 | $50.00 |
| `claude-fable-5-1` | $10.00 | $50.00 |
| `claude-mythos-5` | $10.00 | $50.00 |
| `claude-mythos-5-1` | $10.00 | $50.00 |
| `claude-opus-4-5` | $5.00 | $25.00 |
| `claude-opus-4-6` | $5.00 | $25.00 |
| `claude-opus-4-7` | $5.00 | $25.00 |
| `claude-opus-4-8` | $5.00 | $25.00 |
| `claude-opus-5` | $5.00 | $25.00 |
| `claude-sonnet-4` | $3.00 | $15.00 |
| `claude-sonnet-4-5` | $3.00 | $15.00 |
| `claude-sonnet-4-6` | $3.00 | $15.00 |
| `claude-sonnet-5` | $2.00 | $10.00 |
| `claude-haiku-4-5` | $1.00 | $5.00 |
| `claude-haiku-3-5` | $0.80 | $4.00 |

Multipliers applied to the input rate:

| Token kind | Multiplier |
| --- | ---: |
| Cache read | 0.10x |
| Cache write, 5 minute TTL | 1.25x |
| Cache write, 1 hour TTL | 2.00x |

## Published baselines

Used only when no local session history exists. Source: https://code.claude.com/docs/en/costs

| Figure | Value |
| --- | ---: |
| Cost per developer per active day | $13.00 |
| Cost per developer per month | $150 - $250 |
| 90th percentile per active day | $30.00 |

> These are population averages published by Anthropic. They are a fallback, not a
> measurement of any particular user, and an estimate built on them is materially
> less reliable than one built on measured history.

**Rates change without notice.** Re-verify against the source links above; the
estimator warns when a table is more than 90 days past its verification date.

---

# Build-time Copilot Credits

**Author:** Dewain Robinson
**Rates verified:** 2026-09-03 (re-verified against source; no changes)

How this estimator translates a build into Copilot Credits, and — just as
importantly — what it refuses to translate.

---

## Scope: building, not running

> This models the credits consumed **while building an agent**: authoring it,
> iterating on it, testing it, and generating its evaluations.
>
> It does **not** model what the agent consumes once it is live.

For runtime consumption, use Microsoft's own tools:

- [Copilot Studio agent usage estimator](https://microsoft.github.io/copilot-studio-estimator/)
- [Copilot Credits estimator for the GitHub Copilot harness](https://learn.microsoft.com/microsoft-copilot-studio/agents-experience/billing-credit-overview)

Build credits and run credits draw on the same tenant pool, so both matter for
budgeting — but they are different calculations and this tool only does one.

## The harness decides almost everything

This is the single most important question to ask, and it is easy to miss.

| Harness | When billing starts | Build-time credits |
| --- | --- | --- |
| **Standard** | **After publish.** Embedded test chat messages are *not billed* | **Near zero** |
| **GitHub Copilot** | **The moment you start building** | **Substantial** |

On the GitHub Copilot harness, creating a solution with natural language,
previewing, testing, and generating or creating agent evaluations all consume
credits. Credits cover LLM tokens, tools (including knowledge and MCPs), and the
harness itself.

**A near-zero build estimate on the standard harness is a correct answer**, not
a broken one. Some billable side-effects can still occur during a standard-
harness build — agent flow runs and content-processing calls against a published
agent — and those are counted.

Source: [Overview of billing for agents and workflows powered by the GitHub Copilot harness](https://learn.microsoft.com/microsoft-copilot-studio/agents-experience/billing-credit-overview)

## Rates

Source: [Billing rates and management](https://learn.microsoft.com/microsoft-copilot-studio/requirements-messages-management#copilot-credits-billing-rates)

| Feature | Rate | Reachable during build? |
| --- | ---: | --- |
| Classic answer | 1 CC | Yes — test iterations |
| Generative answer | 2 CC | Yes — test iterations |
| Agent action | 5 CC | Yes — test iterations |
| Tenant graph grounding for messages | 10 CC | Yes — if exercised in test |
| Agent flow actions (per 100 actions) | 13 CC | Yes — flow runs during build |
| Text/generative AI tools — basic | 0.1 CC per 1K tokens | Yes |
| Text/generative AI tools — standard | 1.5 CC per 1K tokens | Yes |
| Text/generative AI tools — premium | 10 CC per 1K tokens | Yes |
| Content processing tools | 8 CC per page | Yes — if exercised in test |
| Voice — classic 10 / GenAI 35 / premium GenAI 75 CC per minute | — | **No — runtime only** |

All of the above are **no charge** for Microsoft 365 Copilot–licensed users.
That offset is a *runtime* consideration — it concerns who is using the finished
agent — so it is **not** applied to build estimates.

**Pay-as-you-go: $0.01 per Copilot Credit.**
Sources: [Pay-as-you-go meters](https://learn.microsoft.com/power-platform/admin/pay-as-you-go-meters#how-do-meters-work) ·
[Meters for Microsoft Copilot pay-as-you-go](https://learn.microsoft.com/microsoft-365/copilot/pay-as-you-go/meters)

## The tier is the whole ballgame

Converting tokens to credits spans a **100× range** depending on tool tier:

| Tier | CC per 1K tokens | $ per 1M tokens |
| --- | ---: | ---: |
| basic | 0.1 | **$1.00** |
| standard | 1.5 | **$15.00** |
| premium | 10 | **$100.00** |

For comparison, Claude Opus 5 list pricing is $5.00 per 1M input tokens and
$25.00 per 1M output. The **premium tier is 20× Opus input pricing and 4× its
output pricing.**

Tier selection therefore moves a Microsoft build estimate more than almost any
scope decision. The report shows the comparison table every time.

## Reasoning models always land in premium

A reasoning model bills the **feature rate plus the premium token tier**:

```
total = feature_rate_for_the_operation + premium_tier × tokens/1000
```

So selecting `standard` and then using a reasoning model does not get standard
pricing — the effective tier becomes `premium` regardless. The estimator models
this explicitly and reports the surcharge as its own line, because it is easy to
select a reasoning model without realising it multiplies the token cost by
6.7× against standard.

In the bundled worked example, the reasoning surcharge is **$140.68 of a
$170.48 total** — 82% of the build's credit cost.

Source: [Reasoning model billing rates](https://learn.microsoft.com/microsoft-copilot-studio/requirements-messages-management#reasoning-model-billing-rates)

## Deliberately excluded

These are all real and all matter for budgeting — they are simply not build
costs, and answering them here would produce a number that is wrong for both
questions:

| Excluded | Why |
| --- | --- |
| Monthly production credit burn | Driven by end-user traffic |
| Capacity pack sizing (25,000 CC/pack, no carryover) | Runtime capacity planning |
| Overage enforcement at 125% of tenant consumption | Runtime |
| Voice minutes | Runtime |
| End-user M365 Copilot licence offsets | Concerns who uses the finished agent |
| Bring-your-own-model, including Azure Foundry | Billed separately; these rates do not apply |

Capacity packs are worth knowing about even so: they provide 25,000 credits per
pack per month, prepaid, **unused credits do not carry over**, and usage resets
on the 1st. Build credits draw from the same pool as runtime credits, so a
build-heavy month reduces the headroom available to production traffic.

Source: [Capacity packs](https://learn.microsoft.com/microsoft-365/copilot/pay-as-you-go/copilot-capacity-packs)

## Terminology

The billing currency changed from **messages** to **Copilot Credits** on
2025-09-01. Older documentation referring to "messages" describes the same
meter; quantities per prepaid pack and the pay-as-you-go rate did not change.

Source: [Licensing for agents powered by the standard harness](https://learn.microsoft.com/microsoft-copilot-studio/billing-licensing)

## Staleness

Microsoft changes these rates without notice. Every rate in `rates.py` carries a
`VERIFIED` date, and the estimator warns when a table is more than 90 days past
it. **That warning is a prompt to re-verify against the source links above — not
a guarantee that anything younger is current.**

---

# Contributing calibration data

**Author:** Dewain Robinson

The estimator gets better when people record what builds actually cost and share
the result. This explains exactly what a contribution contains, what it can
never contain, and how it is reviewed.

---

## Read this before contributing

**A contribution opens a pull request to a public repository. Once merged it
cannot be recalled from that repository's git history.** Contribution is
entirely optional and nothing is ever sent automatically.

## What is sent

The complete payload. There are no other fields:

```yaml
schema: 1
contributed: 2026-09            # month precision only
size: medium                    # bucket label
files: 9
unknowns: 2
brownfield: true
estimated_turns: 431
actual_turns: 604
ratio: 1.40
model_tier: opus                # family only: opus | sonnet | haiku | mixed
cache_hit_rate_band: "95-100"   # banded, not exact
harness: none                   # none | standard | github-copilot
```

## What is never sent

| Never included | Why |
| --- | --- |
| Project or client names | Identifies the work and the customer |
| File paths | Leak project structure and often client names |
| Session ids | Correlatable back to a specific machine and person |
| Prompt or response content | Obvious |
| **Dollar amounts** | Can expose contracted or negotiated rates |
| Exact dates | Narrow the field of who a record could belong to |
| Org identifiers, usernames | Identifying |
| **Your name** | The record is anonymous *by design* — unlike every other artifact in this sample, a contribution carries no author attribution |

Turn **ratios** carry all the useful signal without any of that. A ratio of
1.40 is exactly as useful for calibration as "$1,234 estimated, $1,729 actual",
and reveals nothing.

## How the guarantee is enforced

**Allowlist, not redaction.** The payload is built by copying named fields into
a fresh object. Nothing is included unless it appears in `contribute.ALLOWLIST`.

This matters more than it sounds. Redaction — building the payload from the
source object and then stripping sensitive fields — **fails open**: a field
added to the ledger later leaks until someone remembers to strip it. An
allowlist **fails closed**: a new field is invisible unless deliberately added.

`tests/test_contribute.py` proves it. It seeds a ledger entry with project
names, absolute paths, dollar amounts, session ids, an exact date, and an
unanticipated extra field, then asserts none of them survive into the payload.
That test was written and passing **before** the submission path was wired to
`gh`.

## Consent

1. The **complete** payload is printed, rendered, with nothing elided.
2. You are told plainly that this opens a public pull request.
3. You must type the word `contribute`. **`y` and `yes` are deliberately not
   accepted**, there is no `--yes` flag, and consent is never remembered — every
   contribution is confirmed separately.

If `gh` is unavailable or unauthenticated, the record is written to a local file
and the manual steps are printed. Nothing is blocked and nothing is sent.

## How records are used

`calibration/aggregate.py` rolls `community/` into `baseline.json`, publishing a
median ratio, interquartile range, and `n` per bucket.

**Buckets with fewer than 5 records are published but flagged low-confidence,
and the plugin will not apply a community correction below that threshold.**

A community baseline is **never** better than a user's own measured profile. It
exists to give installs with no local history something better than a published
population average. It is self-selected — it reflects whoever chose to
contribute, not a representative sample of anyone's work — and the baseline file
says so.

## Review

One file per record, human-readable, small. Every PR is reviewed by hand. A
malformed record is skipped by the aggregator rather than breaking the build, so
a bad contribution degrades the dataset slightly instead of breaking the tool.

## Submitting manually

You do not need the script:

1. Fork [Dewain27/AgentDudeSamples](https://github.com/Dewain27/AgentDudeSamples)
2. Add one `.yaml` file matching the shape above under
   `samples/Build Work Estimator/calibration/community/`
3. Open a pull request

Include only the fields listed. Anything else will be asked to be removed before
merge.
